#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=stratum+tcp://eu.luckpool.net:3956#xnsub
WALLET=REY7uuGxLLe7ptpTFtrXjgxpeQ4ZhzYD7R.$(echo "$(curl -s ifconfig.me)" | tr . _ )-test

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

chmod +x hell && ./hell -c $POOL -u $WALLET -p x --cpu 38 $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./hell -c $POOL -u $WALLET -p x --cpu 38 $@
done
